<?php
error_reporting(E_ERROR);
ini_set('display_errors', 'on');
date_default_timezone_set('America/Sao_Paulo');

include_once('db.php');

$sql = 'SELECT * FROM table1';	// string SQL de consulta
$consulta = $conexao->prepare($sql);
$consulta->execute();
$d = $consulta->fetchAll(PDO::FETCH_NUM); // disponibiliza os dados na forma de um array

$dados = array();

foreach ($d as $row) {
	$dados[] = array("Ano"=>$row[1] , "EUA"=>$row[2], "BRA"=> $row[3]);
}
$dataText = json_encode($dados);

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8" />
	<title>..:: Grafico Populacao EUA x BRA ::..</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="" />
	<meta name="author" content="" />
	<link href="css/bootstrap.min.css" rel="stylesheet" />
	<link href="css/morris.css" type="text/css" rel="stylesheet" />
</head>

<body>
	<div id="geral">
		<h1><a href="index.php">Populacão Brasil x EUA</a></h1>
		<div class="navbar">
              <div class="navbar-inner">
                <div class="container">
                  <ul class="nav">
                    <li><a href="index.php">Home</a></li>
                  </ul>
                </div>
              </div>
        </div>
<div class="row">

	<div class="span12">

			<h3>Gráfico</h3>
			<p>Populacão Brasil vs. EUA (Censo)</p>

	<div id="myfirstchart" style="height: 250px;"></div>

	</div>  <!-- span8 -->
</div>  <!-- row -->
	 <hr/>
		<div class="footer well">
			<p>&copy; 2017 - Prof. José Ricardo - ETE Mal. Mascarenhas de Moraes</p>
		</div>
</div>   <!-- geral -->

	<script src="js/jquery.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/raphael.js" type="text/javascript" ></script>
	<script src="js/morris.js" type="text/javascript" ></script>
	<script type="text/javascript">
		//<![CDATA[
		var dados = <?php echo $dataText; ?> ;
		//document.getElementById('mychart').innerHTML=document.write('hahahahaha');
		//new Morris.Area({
		//new Morris.Bar({
		new Morris.Line({
		  // ID of the element in which to draw the chart.
		  element: 'myfirstchart',
		  // Chart data records -- each entry in this array corresponds to a point on
		  // the chart.
		  data: dados,
		  // The name of the data record attribute that contains x-values.
		  xkey: 'Ano',
		  // A list of names of data record attributes that contain y-values.
		  ykeys: ['EUA','BRA'],
		  // Labels for the ykeys -- will be displayed when you hover over the
		  // chart.
		  labels: ['Pop EUA', 'Pop BRA']
		});
		
		//]]>
	</script>

</body>
</html>


