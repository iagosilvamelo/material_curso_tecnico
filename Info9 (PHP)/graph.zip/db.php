<?php
$banco = 'populacao';
$conexao = new PDO('mysql:host=localhost;dbname='.$banco,
					'root',
					'123');
$conexao->setAttribute(PDO::ATTR_ERRMODE,
				PDO::ERRMODE_EXCEPTION);
?>
